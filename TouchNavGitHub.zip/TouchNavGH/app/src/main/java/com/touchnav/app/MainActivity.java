package com.touchnav.app;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Button btnOverlay, btnAccessibility, btnToggleService, btnSettings;
    private TextView tvOverlayStatus, tvAccessibilityStatus, tvServiceStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnOverlay = findViewById(R.id.btn_overlay);
        btnAccessibility = findViewById(R.id.btn_accessibility);
        btnToggleService = findViewById(R.id.btn_toggle_service);
        btnSettings = findViewById(R.id.btn_settings);
        tvOverlayStatus = findViewById(R.id.tv_overlay_status);
        tvAccessibilityStatus = findViewById(R.id.tv_accessibility_status);
        tvServiceStatus = findViewById(R.id.tv_service_status);

        btnOverlay.setOnClickListener(v -> {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        });

        btnAccessibility.setOnClickListener(v -> {
            Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            startActivity(intent);
            Toast.makeText(this,
                    "TouchNav'ı bulun ve etkinleştirin",
                    Toast.LENGTH_LONG).show();
        });

        btnToggleService.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Önce overlay iznini verin!", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!isAccessibilityEnabled()) {
                Toast.makeText(this, "Önce erişilebilirlik servisini etkinleştirin!", Toast.LENGTH_SHORT).show();
                return;
            }
            toggleService();
        });

        btnSettings.setOnClickListener(v ->
                startActivity(new Intent(this, SettingsActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatuses();
    }

    private void updateStatuses() {
        // Overlay
        boolean overlayOk = Settings.canDrawOverlays(this);
        tvOverlayStatus.setText(overlayOk ? "✓ İzin verildi" : "✗ İzin gerekli");
        tvOverlayStatus.setTextColor(overlayOk ? 0xFF4CAF50 : 0xFFFF5252);
        btnOverlay.setEnabled(!overlayOk);
        btnOverlay.setAlpha(overlayOk ? 0.4f : 1f);

        // Accessibility
        boolean accessOk = isAccessibilityEnabled();
        tvAccessibilityStatus.setText(accessOk ? "✓ Servis aktif" : "✗ Servis devre dışı");
        tvAccessibilityStatus.setTextColor(accessOk ? 0xFF4CAF50 : 0xFFFF5252);
        btnAccessibility.setEnabled(!accessOk);
        btnAccessibility.setAlpha(accessOk ? 0.4f : 1f);

        // Service running
        boolean running = AppPrefs.isServiceRunning(this);
        tvServiceStatus.setText(running ? "● Çalışıyor" : "● Durduruldu");
        tvServiceStatus.setTextColor(running ? 0xFF4CAF50 : 0xFF888888);
        btnToggleService.setText(running ? "Durdur" : "Başlat");
        btnToggleService.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(running ? 0xFFE94560 : 0xFF0F3460));
    }

    private void toggleService() {
        Intent serviceIntent = new Intent(this, FloatingButtonService.class);
        if (AppPrefs.isServiceRunning(this)) {
            stopService(serviceIntent);
            AppPrefs.setServiceRunning(this, false);
        } else {
            startForegroundService(serviceIntent);
        }
        // Small delay then refresh
        btnToggleService.postDelayed(this::updateStatuses, 500);
    }

    private boolean isAccessibilityEnabled() {
        AccessibilityManager am =
                (AccessibilityManager) getSystemService(ACCESSIBILITY_SERVICE);
        if (am == null) return false;
        List<AccessibilityServiceInfo> enabledServices =
                am.getEnabledAccessibilityServiceList(
                        AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
        for (AccessibilityServiceInfo info : enabledServices) {
            if (info.getId().contains(getPackageName())) return true;
        }
        return false;
    }
}
